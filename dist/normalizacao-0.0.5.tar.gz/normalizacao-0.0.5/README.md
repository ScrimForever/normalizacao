# normalizacao
Normalizações para métodos multicritérios.
